package com.ts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpDeptApplicationTests {

	@Test
	void contextLoads() {
	}

}
